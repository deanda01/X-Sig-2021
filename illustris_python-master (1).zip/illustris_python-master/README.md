# README #

The Illustris Simulation: Public Data Release

Example code (Python).

See the [Illustris Website Data Access Page](http://www.illustris-project.org/data/) for details.

